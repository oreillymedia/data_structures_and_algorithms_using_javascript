for (var i = 0; i < numElements; ++i) {
   this.dataStore[i] = Math.floor(Math.random() * (numElements+1));
}