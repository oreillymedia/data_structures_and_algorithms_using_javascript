var numElements = 10;
var mynums = new CArray(numElements);
print(mynums.toString());
mynums.bubblesort();
print();
print(mynums.toString());