var x = 3;
var y = 1.1;
print(x + y);
var z = x * y;
print(z.toFixed(2));
print((x+y)*(x-y));
var z = 9;
print(Math.sqrt(z));
print(Math.abs(y/x));
