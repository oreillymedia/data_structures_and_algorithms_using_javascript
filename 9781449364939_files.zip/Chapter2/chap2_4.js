var cis = ["Mike","Clayton","Terrill","Danny","Jennifer"];
var dmp = ["Raymond","Cynthia","Bryan"];
var it = cis.concat(dmp);
print(it); 
it = dmp.concat(cis);
print(it);